
//***** INTERNAL ADANALYST VARIABLES (FLAGS/etc)

//var HOST_SERVER = 'https://adanalyst.mpi-sws.org/';
//var HOST_SERVER = 'https://lig-adanalystplus-test.imag.fr/';

var HOST_SERVER = 'https://adanalystplus.imag.fr/';
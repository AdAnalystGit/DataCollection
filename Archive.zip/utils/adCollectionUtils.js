//The MIT License
//
//Copyright (c) 2018 Athanasios Andreou, <andreou@eurecom.fr>
//
//Permission is hereby granted, free of charge, 
//to any person obtaining a copy of this software and 
//associated documentation files (the "Software"), to 
//deal in the Software without restriction, including 
//without limitation the rights to use, copy, modify, 
//merge, publish, distribute, sublicense, and/or sell 
//copies of the Software, and to permit persons to whom 
//the Software is furnished to do so, 
//subject to the following conditions:
//
//The above copyright notice and this permission notice 
//shall be included in all copies or substantial portions of the Software.
//
//THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
//EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES 
//OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. 
//IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR 
//ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, 
//TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
//SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.



//***** INTERNAL ADANALYST VARIABLES (FLAGS/etc)
var COLLECTED = 'ad_collected'; //inserted to an ad to signify it was collected
var TYPES = {"frontAd" : "frontAd", "sideAd" : "sideAd"}; // possible types of ads ad analyst collects
var DOM_AD = 'domAD'; //json key for storing the source code of a side adß
var GRAB_ME = 'grab_me' //if added as a class this ad will be captured by adanalyst
BROWSERS = {CHROME:'chrome',FIREFOX:'firefox'} // constants for browser used (ti facukutate cgabges ub tge ΑΟΘ)



//***************HTML TAGS/ATTRIBUTES/PATTERNS*********************
var LINK_TAG = 'a';
var CLASS = 'class';
var AJAXIFY = 'ajaxify';
var ARIA_LABEL = "aria-label";
var DATA_GT = 'data-gt';
var DATA_TO_LOG = 'data_to_log';
var AD_ID = 'ad_id';
var AD_ACCOUNT_ID = 'ad_account_id';
var NOT_FRONT_AD = 'adsCategoryTitleLink'; //Tag that if exists then frame is not front ad
var USER_ID_TAG = /"USER_ID":"[0-9][0-9]+"/; //user id pattern in facebook source code that allow us to retrieve user id
var NUMBER_TAG = /[0-9]+/; //General pattern for number in order to get the user idß
var HYPERFEED_STORY = 'hyperfeed_story_id'; //attribute that makrs a full front ad html object
var DATA_HOVERCARD = 'data-hovercard'; //attribute that allow us to detect the advertiser in the front ad html
var FT_ENT_IDENTIFIER = 'ft_ent_identifier'; //attrubte to check if the ad contains a video
var INPUT = 'input';
var VALUE = 'value';
var NAME = 'name';
var POLITICAL_AD= "entry_type=political_ad_subtitle" //allows us to detect political ads
var BACKGROUNDIMAGE = "background-image: url"; //used to detect background image of videos (we do not save the actual videos)
var ADVERTISER_ID_PATTERN_IDENTIFIER = /id=?[0-9]+/ 
var UISTREAMPRIVACY = 'uiStreamPrivacy' //used to detect sponsored contenttß
var AJAXIFYPATTERNSIDEAD= /"\\\/waist_content\\\/dialog\S+?"/ //pattern to get parameters for explanation urls from sideadsß
var ADIDPATTERN = /id=[0-9]+/; //pattern to get the ad id  of the ad (new)
var DATATESTID = 'data-testid'; //Attribute name used to detect sponsored tags
var SUBTITLE_TAG_DATATESTID= 'fb-testid_feed-subtilte'; //Attribute value that can help detect the sponsored tag with the new way it is presented with sponosred letters as attribute values
var DATACONTENT = 'data-content'; //attribute that contains the words that mark the sponsored tag in new iteration

var CLIENTTOKEN_PATTERN = /client_token=(.*?)&/

//*****************Landing URLS extraction variables ******************
var ONMOUSEOVER = 'onmouseover'; // attributes whose values store actual links for landing pagesm, for some links and not facebook's ones for parsing landing pages in frontads
var ONMOUSEDOWN= 'onmousedown'; // attributes whose values storeactual landing pages of links, for some links for sideads
var SWAPINGFUNCTION = /"[\s\S]*"/; // related to getting landing urls
var LINKSHIMASYNCLINK = 'LinkshimAsyncLink';

//*************TEXT segments that allow the detection of ads explanations e.t.c.*******
//
//
var EXPLANATION_TEXT = ["Why am I seeing this?", "Why am I seeing this ad", "Pourquoi est-ce que je vois ça ?", "Pourquoi je vois cette pub ?", "Pourquoi est-ce que je vois cette publicité?", "¿Por qué veo esto?", "¿Por qué veo este anuncio ?", "Warum wird mir das angezeigt?", "Warum sehe ich diese Werbeanzeige?", "Γιατί το βλέπω αυτό;", "Γιατί βλέπω αυτή τη διαφήμιση;", "Por que estou vendo isso?", "Por que estou vendo esse anúncio?", "Zašto mi se ovo prikazuje?", "Zašto mi se prikazuje ovaj oglas?", "Perché visualizzo questa inserzione?", "De ce văd asta?", "De ce văd această reclamă?", "为什么我会看到这条广告？", "لماذا أرى هذا الإعلان؟", "मुझे यह विज्ञापन क्यों दिखाई दे रहा है?", "Зашто ми се приказује ова реклама?", "Почему я вижу эту рекламу?", "この広告が表示されている理由", "ทำไมฉันจึงเห็นโฆษณานี้", "Dlaczego widzę tę reklamę?"];
var MENU_LABEL = ["Report or learn more", "Signaler ou en savoir plus", "Reportar u obtener más información", "Melde dies oder erfahre mehr darüber", "Υποβάλετε αναφορά ή μάθετε περισσότερα", "Denuncie ou saiba mais", "Prijavi ili saznaj više", "Segnala od ottieni maggiori informazioni", "Raportează sau află mai multe"];
var SPONSORED = ['Sponsored', 'Sponsorisé', 'Commandité', 'Publicidad', 'Gesponsert', 'Χορηγούμενη', 'Patrocinado', 'Plaćeni oglas', 'Sponsorizzata ', 'Sponsorizzato', 'Sponsorizat', '赞助内容', 'مُموَّل', 'प्रायोजित', 'Спонзорисано', 'Реклама', '広告', 'ได้รับการสนับสนุน', 'Sponsorowane']; //English French Spanish German Greek Portuguese(Brazil) Croatian Italian c Romanian Chinse Hindi Serbian Rusian Japannese Thai Polish
var MORE_LINK_FRONT_LABEL = ['Story options', 'Options des actualités', "Options de l’actualité", 'Opciones de la historia', 'Meldungsoptionen', 'Story-Optionen', 'Επιλογές ανακοινώσεων', 'Επιλογές ανακoίνωσης', 'Opções da história', 'Opções do story', 'Opcije priče', 'Opzioni per la notizia', 'Opţiuni pentru articol', '动态选项', 'خيارات القصص', 'कहानी विकल्प', 'Опције приче', 'Параметры новостей', '記事オプション', '記事のオプション', 'ตัวเลือกเรื่องราว', 'Opcje zdarzeń'];


//*****@deprecated EXPLANATION SUB URL TODO:RECHECK IF ALL OF THEM ARE DEPRECATED***********
var AD_LINK = '/ads/preferences/dialog/?ad_id=';
var SPLIT_AD_URL = '&';
var OK = 'OK';
var NOT_OK = 'NOT_OK';
var FRONTAD_OVERLAY = 'uiContextualLayerPositioner uiLayer';
var LINKSEPARATOR = "|||";
var ADVERTISER_FB_ID_PATTERN = '/ajax/hovercard/page.php?id=';
var STYLE = 'style';
var CONTENT_AREA = 'contentArea';
var FRONTADPOSTPATTERN = /feedback_target_id%5C%5C%5C%22%3A[0-9]+/;
var FRONTADPOSTPATTERNSTRING = "feedback_target_id%5C%5C%5C%22%3A";
var FRONTADPOSTPATTERN2 = /AI%5C%5C%5C%5Cu00[a-z0-9]+%5C/
var FRONTADPOSTPATTERNSTRING2a = "AI%5C%5C%5C%5Cu00"
var FRONTADPOSTPATTERNSTRING2b = "%5C"
var FRONTADPOSTPATTERN3= /%22qid%22%3A%22[0-9]+%22/
var FRONTADPOSTPATTERNSTRING3a = "%22qid%22%3A%22"
var FRONTADPOSTPATTERNSTRING3b = "%22"
//var URL_REGEXP = /[-a-zA-Z0-9@:%_\+.~#?&//=]{2,256}\.[a-z]{2,4}\b(\/[-a-zA-Z0-9@:%_\+.~#?&//=]*)?/gi;
var URL_REGEXP= /https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9]\.[^\s]{2,}/










///"background-image: url(https://scontent.xx.fbcdn.net/v/t15.0-10/p480x480/17621064_1769517093062117_5270720042437181440_n.jpg?oh=c6831f7394bb102f943e26ea541b167c&oe=595B080B);"


//LinkshimAsyncLink.swap(this, "http:\/\/www.asos.de\/herren\/entdecken\/denim\/?affid=17593");





/**
 * Detect which of the supported browsers are being used.
 */
function BrowserDetection() {

    if (navigator.userAgent.search("Chrome") >= 0) {
        return BROWSERS.CHROME;
            
        }
   if (navigator.userAgent.search("Firefox") >= 0) {
        return BROWSERS.FIREFOX;
   }
    return NaN;
}

/**
 * Check whether string is a number
 * 
 * @param  {string}  value value which is being checked whether it is a number
 * @return {Boolean}       true if number, else false
 */
function isNumeric(value) {
    return /^\d+$/.test(value);
}


/**
 * Checks if value is an email by creating an input that is supposed to be an email. 
 * For older browsers it includes a simple test with regex
 * 
 * @param  {string}  value value to check if is email
 * @return {Boolean}       true if it is email else false
 */
function isEmail(value) {
  var input = document.createElement('input');

  input.type = 'email';
  input.required = true;
  input.value = value;

  return typeof input.checkValidity === 'function' ? input.checkValidity() : /\S+@\S+\.\S+/.test(value);
}

/**
 * replace all occurences of pattern to string
 * 
 * @param  {stirng} search      string substring to be replaced
 * @param  {string} replacement string substring to be used as a replacement
 * @return {string}             new string
 */
String.prototype.replaceAll = function(search, replacement) {
    var target = this;
    return target.split(search).join(replacement);
};


/**
 * detect Facebook user id in the source code of the user
 *
 * @param  {string} elem source code of the Facebook page
 * @return {string}      user id of user that is logged in
 */
function getUserIdStr(elem) {
    var idTag = elem.match(USER_ID_TAG);
    if (!idTag) { 
        return null
    }
    return idTag[0].match(NUMBER_TAG)[0]
}


/**
 * get the user id of the logged in user
 * 
 * @return {string} user id of user that is logged in
 */
function getUserId() {
    return getUserIdStr(document.head.innerHTML)
}



/**
 * return an array with each element appearing only once
 *
 * @return {object} array that contains each element of the initial array only once
 */
Array.prototype.unique = function unique() {
        var self = this;
        return self.filter(function(a) {
            var that = this;
//            console.log(that);
//            console.log(a)
//            console.log(that[a])
            return !that[a] ? that[a] = true : false;
        },{});}

/**
 * extend an array adding the elements of another array. (similar to python extend)
 * 
 * @param  {object} other_array array whose elements will be added to the initial array
 * @return            
 */
Array.prototype.extend = function (other_array) {
    /* you should include a test to check whether other_array really is an array */
    other_array.forEach(function(v) {this.push(v)}, this);    
}

/**
 * return set difference (a-b)
 * 
 * @param {object} a initial set
 * @param {object} b set which contains the elements to be removed 
 * @return  {Set} new set containing a-b
 */
function setDiff(a,b) {
    return new Set(
        [...a].filter(x => !b.has(x)));

}

/**
 * return the set that contains the keys of a json object
 * 
 * @param  {object} obj input object 
 * @return {Set}     set containing the keys of a json object
 */
function getSetOfKeys(obj) {
    return new Set(Object.keys(obj))
}

/**
 * check whetehre two objects are contain the same elements
 *
 * @param  {object}  value first object
 * @param  {object}  other second object
 * @return {Boolean}       true if both objects contain the same elements, else false 
 */
function isEqual(value, other) {

    // Get the value type
    var type = Object.prototype.toString.call(value);

    // If the two objects are not the same type, return false
    if (type !== Object.prototype.toString.call(other)) return false;

    // If items are not an object or array, return false
    if (['[object Array]', '[object Object]'].indexOf(type) < 0) return false;

    // Compare the length of the length of the two items
    var valueLen = type === '[object Array]' ? value.length : Object.keys(value).length;
    var otherLen = type === '[object Array]' ? other.length : Object.keys(other).length;
    if (valueLen !== otherLen) return false;

    // Compare two items
    var compare = function (item1, item2) {
        // Code will go here...
    };

    // Compare properties
    var match;
    if (type === '[object Array]') {
        for (var i = 0; i < valueLen; i++) {
            compare(value[i], other[i]);
        }
    } else {
        for (var key in value) {
            if (value.hasOwnProperty(key)) {
                compare(value[key], other[key]);
            }
        }
    }

    // If nothing failed, return true
    return true;

};


/**
 * returns only the ad objects that exist in the second object but not the first
 * 
 * @param  {object} oldAds ads that need to be excluded from the final object
 * @param  {object} newAds ads that will be included to the final object if they do not exist on old ads
 * @return {[type]}        ads that only exist in the newAds object
 */
function getNewAds(oldAds,newAds) {
    
    var oldIds = getSetOfKeys(oldAds);
    var newIds = getSetOfKeys(newAds);
    
    var onlyNewIds = setDiff(newIds,oldIds);
    var adsToSend = {}
    for (let i of onlyNewIds) {
        adsToSend[i] = newAds[i];
    }
    return adsToSend
}


/**
 * @deprecated extract ad id from ajaxify attibute value 
 * 
 * @param  {string} ajaxify sttribute value for the "ajaxify" attribute that exists in Facebook HTML
 * @return {adId}         ad id
 */
function extract_ad_id(ajaxify){
//    slice the first part of the url
    var sliced_url = ajaxify.slice(ajaxify.indexOf(AD_LINK)+AD_LINK.length,ajaxify.length);
   return sliced_url.split(SPLIT_AD_URL)[0]
     
}


/**
 * extract ad id and the rest of the parameters required to build the explanation url 
 * for the ad from the "ajaxify" attribute value (for sideads)
 * 
 * @param  {string} resp string to search for the ajaxify parameter
 * @return {object}      parameters to build the explanation url and the ad id
 */
function grabParamsFromSideAdAjaxify(resp) {
        var text = resp.replaceAll('\\\\\\','\\').replaceAll('\\\\','\\').replaceAll('amp;','');
        var requestParams = text.match(AJAXIFYPATTERNSIDEAD)[0].replace('"\\\/waist_content\\\/dialog\\\/?','');
                // requestParams.slice(0,requestParams.length-2)
        requestParams = decodeURIComponent(unicodeToChar(requestParams.slice(0,requestParams.length-2)));
        var serialized = requestParams.match('serialized_nfx_action_info={(.*)}')[1]; 
        requestParams = requestParams.replaceAll(serialized,encodeURIComponent(serialized));
        var clientToken = requestParams.match(CLIENTTOKEN_PATTERN)[1];
        var adId = requestParams.match(ADIDPATTERN)[0].match(NUMBER_TAG)[0];
        return {requestParams:requestParams,adId:adId,clientToken:clientToken}    
    
}




/**
 * return all menu button elements in a DOM element (they contains the "Why Am I Seeing this?"  BUtton). 
 * (for a single side ad, it should be only one). Detected by the "Report or learn more" title
 *
 * 
 * @param  {object} doc DOM element to be examined
 * @return {Array}      array containing all menu DOM elements that were detected
 */
function get_dropdown_ad_menus(doc){
    var links = doc.getElementsByTagName(LINK_TAG);
    var menus = [];
    for (var i=0;i<links.length;i++){
        var link = links[i];
        var menuLabel = link.getAttribute(ARIA_LABEL);
        if ((menuLabel) && (MENU_LABEL.indexOf(menuLabel)>=0)) {
            menus.push(link)
        }
        }
    return menus
    
}


function unicodeToChar(text) {
  return text.replace(/\\u[\dA-F]{4}/gi, 
    function (match) {
      return String.fromCharCode(parseInt(match.replace(/\\u/g, ''), 16));
      });
  }


/**
 * return the side ads in the page.
 *
 * @return {object} object containing all the sideads in the page (their ad id is the key of each side ad)
 */
function getSideAds() {
    var ads = {};
    var menus = get_dropdown_ad_menus(document);
    for (var i=0;i<menus.length;i++) {
        var menu = menus[i]
//        putting quotes in numbers because of javascript mismanagement of bigints
        if (filterCollectedAds([menu.parentElement.parentElement.parentElement]).length==0) {
            continue
        }
        var adId = JSON.parse(menu.getAttribute(DATA_GT).replace(/([\[:])?(\d+)([,\}\]])/g, "$1\"$2\"$3"))[DATA_TO_LOG][AD_ID].toString()
        var advertiserId = JSON.parse(menu.getAttribute(DATA_GT).replace(/([\[:])?(\d+)([,\}\]])/g, "$1\"$2\"$3"))[DATA_TO_LOG] [AD_ACCOUNT_ID].toString();
        var isCollected = false;
       
       

        ads[adId] ={};
        ads[adId][DOM_AD] =menu.parentElement.parentElement.parentElement;
        ads[adId][AD_ACCOUNT_ID] = advertiserId;
    }
    
    return ads
}

/**
 * check if DOM element is hidden
 *
 * 
 * @param  {object}  el DOM element to be examined
 * @return {Boolean}    true if DOM element is hidden, else false
 */
function isHidden(el) {
    return (el.offsetParent === null)
}



/**
 * check if DOM element is scrolled into the view of the user
 *
 * 
 * @param  {object}  elem DOM element to be examined
 * @return {Boolean}      true if DOM element is scrolled into the view of the user else, false
 */
function isScrolledIntoView(elem)
{
    if (isHidden(elem)){
        return false
    }
//    return true
    var docViewTop = $(window).scrollTop();
    var docViewBottom = docViewTop + $(window).height();

    var elemTop = $(elem).offset().top;
    var elemBottom = elemTop + $(elem).height();

    return ((elemBottom <= docViewBottom) && (elemTop >= docViewTop));

}


//--------------------Mouse - Event - Tracking --------------------///
/**
 * get the DOM position of ad
 *
 * 
 * @param  {object}  elem DOM element to be examined
 * @return {Array}   return [top, bottom] of the DOM
 *                   return [-1,-1] if the elem is hidden
 */
function getDomPosition(elem) {
    if (isHidden(elem)) {
        return [-1, -1]
    }

    var elemTop = $(elem).offset().top;
    var elemBottom = elemTop + $(elem).height();

    return [elemTop, elemBottom]
}


/**
 * get coordinates of DOM elem
 *
 * 
 * @param  {object}  elem DOM element to be examined
 * @return {Array}   return [top, lef, bottom, right] of elem
 *                   return [-1,-1,-1,-1] if the elem is hidden
 */
function getElementCoordinate(elem) {
    if (elem == undefined || isHidden(elem)) {
        return undefined
    }

    var elemTop = $(elem).offset().top;
    var elemLeft = $(elem).offset().left;
    var elemBottom = elemTop + $(elem).height();
    var elemRight = elemLeft + $(elem).width();

    return [elemTop, elemLeft, elemBottom, elemRight]
}

/**
 * convert static coordinates to relative coordinate
 * @param {Array} array of [top,lef, bottom,right] static coordinate
 * @return {Array} [top, left,bottom,right] relative coordinate 
 */
function toRelativeCoordinate(coordinates) {
    if (coordinates == undefined) {
        return undefined;
    }

    let A = coordinates.slice();
    let elmHeight = A[2] - A[0];
    let screen = getUserView(); //[top,bottom]
    //Element is in user view
    if ((A[2] <= screen[1]) && (A[0] >= screen[0])) {
        A[0] -= screen[0];
        A[2] = A[0] + elmHeight
        return A
    }
    //Invisible (bellow or abve)
    else if (A[0] > screen[1] || A[2] < screen[0]) {
        return undefined
    }
    //Partially visible
    else {
        if (A[0] >= screen[0]) { //upper part is visible
            A[0] -= screen[0];
            A[2] = screen[1] - screen[0];
            return A
        }
        else if (A[2] <= screen[1]) { //lower part is visible
            A[0] = 0;
            A[2] = A[2] - screen[0];
            return A
        }
        else {
            return undefined
        }
    }
}



/**
 * 
 * @param {Array} ralative_coordinates of element
 * @return {Array} [visible height , invisible height, visible_state] of elm
 *                   visible_state: -1 : upper part visible, 1 - lower part visible, 0: visible all
 */
function getVisibleHeight(elm) {
    var domPos = getElementCoordinate(elm);
    var relPos = toRelativeCoordinate(domPos);
    if (relPos == undefined) //in case elm is not in screen
        return undefined
    var state = 0;
    if (relPos[2] - relPos[0] == domPos[2] - domPos[0]) {
        state = 0
    }
    else if (relPos[0] == 0) {
        state = -1
    }
    else {
        state = 1
    }
    return [relPos[2] - relPos[0], domPos[2] - domPos[0], state]
}


/**
 * get the limit of user view
 *
 * 
 * @param  {object}  elem DOM element to be examined
 * @return {Array}   return [top,bottom] of user view
 */
function getUserView() {

    //    return true
    var docViewTop = $(window).scrollTop();
    var docViewBottom = docViewTop + $(window).height();

    return [docViewTop, docViewBottom]

}

function get_advertiser_logo(html_ad_id){
    let frontAd = document.getElementById(html_ad_id);
    if (frontAd == undefined)
        return []
    let links = frontAd.getElementsByTagName(LINK_TAG);
    let link = null
    for (let i = 0; i < links.length; i++) {
        if (links[i].hasAttribute(DATA_HOVERCARD) && (links[i].getElementsByTagName('img').length > 0)) {
            link = links[i];
            break
        }
    }
    return link 
}

function get_advertiser_elm(html_ad_id) {
    let frontAd = document.getElementById(html_ad_id);
    if (frontAd == undefined)
        return []
    let links = frontAd.getElementsByTagName(LINK_TAG);
    let link = null
    for (let i = 0; i < links.length; i++) {
        if (links[i].hasAttribute(DATA_HOVERCARD) && (links[i].getElementsByTagName('img').length == 0) && links[i].className.indexOf('profileLink') == -1) {
            link = links[i];
            break
        }
        
    }
    return link
}

//-----------------------Mouse_track_Rosa---------------------//


function MouseTrack() {

    var myArray=[];
    var ad_extract = getFrontAdFrames();
   // var ad_extract = document.getElementById('ad_extract');
    console.log(ad_extract);
    ad_extract.addEventListener('mouseover', function () {
        toggleRecordBQ();
    });
    ad_extract.addEventListener('mouseout', function () {
        mus.stop();

    });
    myArray.push(mus.getData());
return myArray
}

//--------------------END: Mouse - Event - Tracking --------------------///
/**
 * check if DOM element is/was scrolled into the view of the user
 *
 * 
 * @param  {object}  elem DOM element to be examined
 * @return {Boolean}      true if DOM element is scrolled into the view of the user else, false
 */
function isWasScrolledIntoView(elem)
{
    // if (isHidden(elem)){       
    //     return false
    // }
//    return true
    var docViewTop = $(window).scrollTop();
    var docViewBottom = docViewTop + $(window).height();

    var elemTop = $(elem).offset().top;
    var elemBottom = elemTop + $(elem).height();
    // console.log(elemBottom + " : " + docViewBottom)
    // console.log((elemBottom <= docViewBottom))
    return (elemBottom <= docViewBottom);
    //return ((elemBottom <= docViewBottom) && (elemTop >= docViewTop));
}

/**
 * filter out links that do not correspond to front ad links (sponsored) that are not hidden from array.
 * can detect ads that are tagged with the political tag, but for the rest, 
 * it currently cannot capture them for some users 
 * (TODO: check if it is for more users these days) due to 
 * changes in the way Facebook shows sponsored ad, 
 * so it should be used in combination with other functions that can detect front ads
 * 
 * @param  {Array} lst  array that contains links marked with the <a> tag
 * @return {Array}      array that contains only links are front Ad links (and not hidden)
 */
function filterFrontAds(lst) {
    var newLst = [];
    for (var i=0;i<lst.length;i++) {
        let ajaxify = lst[i].getAttribute(AJAXIFY);
        
        if ((ajaxify!=null) && (ajaxify.indexOf(POLITICAL_AD)>-1)   && (isScrolledIntoView(lst[i])) && (lst[i].getAttribute(CLASS).indexOf(NOT_FRONT_AD)===-1)){
             newLst.push(lst[i]);
            continue
        }

        if ((SPONSORED.indexOf(lst[i].text)>=0 ) && (lst[i].getAttribute(CLASS)) &&  (lst[i].getAttribute(CLASS).indexOf(NOT_FRONT_AD)===-1) && (isScrolledIntoView(lst[i]))) {
            newLst.push(lst[i])

        }
        
                    if ((SPONSORED.indexOf(lst[i].text)>=0 ) && (lst[i].getAttribute(CLASS)) &&  (lst[i].getAttribute(CLASS).indexOf(NOT_FRONT_AD)===-1) && (!isScrolledIntoView(lst[i]))){
                console.log(lst[i])
                            console.log('*****************HIDDEN*************');

            }
    }
    
    return newLst
}

function filterHiddenFrontAds(lst) {
    var newLst = [];
    for (var i = 0; i < lst.length; i++) {
        let ajaxify = lst[i].getAttribute(AJAXIFY);

        if ((ajaxify != null) && (ajaxify.indexOf(POLITICAL_AD) > -1) && (!isScrolledIntoView(lst[i])) && (lst[i].getAttribute(CLASS).indexOf(NOT_FRONT_AD) === -1)) {
            newLst.push(lst[i]);
            continue
        }

        if ((SPONSORED.indexOf(lst[i].text) >= 0) && (lst[i].getAttribute(CLASS)) && (lst[i].getAttribute(CLASS).indexOf(NOT_FRONT_AD) === -1) && (!isScrolledIntoView(lst[i]))) {
            newLst.push(lst[i])

        }

        // if ((SPONSORED.indexOf(lst[i].text) >= 0) && (lst[i].getAttribute(CLASS)) && (lst[i].getAttribute(CLASS).indexOf(NOT_FRONT_AD) === -1) && (!isScrolledIntoView(lst[i]))) {
        //     console.log(lst[i])
        //     console.log('*****************HIDDEN*************');

        
    }

    return newLst
}

/**
 * filter out links that are not ads and are hidden, from the links 
 * that are signified as sponsored content through their class 
 * 
 * @param  {Array} lst  array that contains links marked with the <a> tag
 * @return {Array}      array that contains only links are front Ad links (and not hidden)
 */
function filteredClassedAds(lst) {
    var newLst = [];
    for (var i=0;i<lst.length;i++) {
        if ( (isScrolledIntoView(lst[i]))) {
            newLst.push(lst[i])

        }
        
                    if ((SPONSORED.indexOf(lst[i].text)>=0 ) && (lst[i].getAttribute(CLASS)) &&  (lst[i].getAttribute(CLASS).indexOf(NOT_FRONT_AD)===-1) && (!isScrolledIntoView(lst[i]))){
                console.log(lst[i])
                            console.log('*****************HIDDEN classed ads*************');

            }
    }
    
    return newLst
}




//function getParentAdDiv(elem) {
//    if (count===0) {
//        return elem;
//    }
//    return getParentNode(elem.parentElement,count-1);
//}
//


/**
 * return the ad div that corresponds to the whole ad object
 *
 * @param  {object} elem DOM element that is a child the ad DOM element
 * @return {object}      DOM element of the whole ad
 */
function getParentAdDiv(elem) {
    if ((elem.id.length>0) && (elem.id.indexOf(HYPERFEED_STORY)!==-1)){
        return elem;
    }
    return getParentAdDiv(elem.parentElement);
}

/**
 * return x,y coordinates of a DOM element
 * @param  {object} el DOM element
 * @return {object}    x,y coordinates of el
 */
function getPos(el) {
    // yay readability
    for (var lx=0, ly=0;
         el != null;
         lx += el.offsetLeft, ly += el.offsetTop, el = el.offsetParent);
    return {x: lx,y: ly};
}


/**
 * filter out ads that have already been marked as collected
 *
 * @param  {array} ads array containing all the ads
 * @return {array}     array containing all the ads that have not been marked as collected
 */
function filterCollectedAds(ads) {
    var filteredAds = [];
    for (let i=0;i<ads.length;i++) {
        let ad = ads[i];
        if (ad.className.indexOf(COLLECTED) != -1) {
            continue
        }
        filteredAds.push(ad);
    }
    return filteredAds;
}


/**
 * filter out css sheets that for sure do not contain the class of the sponsored tag
 * (to be used in older method that detects ads)
 * 
 * @param  {array} sheets array containing all the CSS sheets of the page
 * @return {array}        array containing sheets that for sure do not contain the class of the sponsored tag
 */
function filterSheets(sheets) {
    var filteredSheets = [];
    for (let i=0;i<sheets.length;i++){
        if (sheets[i].href && ((sheets[i].href.indexOf("https://www.facebook.com/rsrc.php")>-1) ||(sheets[i].href.indexOf("data:text/css; charset=utf-8,._")>-1)) )  {
            continue
        }
        filteredSheets.push(sheets[i])
    }
    return filteredSheets
}



/**
 * find the class name of the sponsored tag, if it is included in the page 
 * (old method that do not work any more)
 *
 * @param  {object} sheet css sheet
 * @return {string}       class name of string with the sponsored class
 */
function findSponsoredClass(sheet) {
    
    if ((!sheet.hasOwnProperty('rules')) || (!sheet.hasOwnProperty('cssRules'))) {
        return
    }
    
    let rules = sheet.hasOwnProperty('rules')?sheet.rules:sheet.cssRules
    if (!rules) {
         console.log(rules)
        return 
    }
    
    for (var i=0;i<rules.length;i++) {
        if (!rules[i].cssText) {
            continue
        }
        
        var text = rules[i].cssText;
        for (let k=0;k<SPONSORED.length;k++) {
            if (text.indexOf('::after { content: "'+SPONSORED[k]+'"; }')>-1) {
            return text.replace('::after { content: "'+SPONSORED[k]+'"; }','')
        }
            
        }
        
        
    }
    return 
}


/**
 * get class name from the sponsored tag by searching at an array of CSS sheets
 * 
 * @param  {array} filteredSheets array of css sheets
 * @return {string}               class name of sponsored tag
 */
function getSponsoredFromClasses(filteredSheets) {
        for (let i=0;i<filteredSheets.length;i++) {
        try {    
        sponsoredClass = findSponsoredClass(filteredSheets[i])
        if (sponsoredClass) {
            return sponsoredClass.slice(1,sponsoredClass.length)
        }
        }
        catch(err) {
            console.log("Exception in getSponsoredFromClasses, " + i);
            console.log(err);
        }
        
    }
    return
    
}


/**
 * find front ads that can be detected throught their css class 
 * (old method that doesn't work any more)
 * 
 * @return {array} array of front ad objects
 */
function getFrontAdsByClass() {
    
    var sheets = document.styleSheets;
    var filteredSheets = filterSheets(sheets);
    var sponsoredClass = getSponsoredFromClasses(filteredSheets) 
    
    if (!sponsoredClass) {
        return []
    }
    
    return filteredClassedAds(document.getElementsByClassName(sponsoredClass));

    
}


/**
 * Get text of children of DOM element that is visible
 * 
 * @param  {array} children array that contains children of DOM element
 * @return {string}         non hidden text that is included in the DOM elements of children array
 */
function getNonHiddenTextByChildren(children){
        var txt = ''
    
    for (let i=0;i<children.length;i++) {
        
        if ((getComputedStyle(children[i])['font-size'] === "0px") || (getComputedStyle(children[i])['opacity'] === "0")  ){
            continue;
        }
        txt += children[i].innerText;
    }
    
    return txt
}


// 
/**
 * checks if link contains hidden sponsored letters. 
 * Facebook currently adds in the "sponsored" tag hidden letters with font-size:0px or opacity of 0, 
 * so this is required to find sponsored tags
 *
 * @param  {object}  elem DOM element(link) to be examined
 * @return {Boolean}      true if it contains the masked "Sponsored" tag, else false
 */
function isLinkSponsoredHiddenLetters(elem) {
    if (elem.children.length!==1) {
        return false;
    }
    
    if (elem.children[0].children.length===0) {
        return false;
    }
    
    var children = elem.children[0].children;
    
    var tag = getNonHiddenTextByChildren(children);

    for (let i=0;i<SPONSORED.length;i++) {
        if (tag===SPONSORED[i]) {
            return true;
        }
    }
    
    return false
}


/**
 * Get text of children of DOM element that is visible (revision August 2019)
 * 
 * @param  {array} children array that contains children of DOM element
 * @return {string}         non hidden text that is included in the DOM elements of children array
 */
function getNonHiddenTextInAttributeByChildren(children){
    var txt = '';
    // console.log(children)
    //some weird timestamp thing that appears some times
    if (children.length==1){
        return txt
    }
    for (let i=0;i<children.length;i++) {

        var node = children[i];

        if (!node.hasAttribute(DATACONTENT)) {

            var child = children[i].childNodes;
        // console.log(child)
            if ((child==null) || (child.length!=1)) {
                continue

            }

            node = child[0]

        }

        // console.log(typeof(child),getComputedStyle(child))

        
        if ((getComputedStyle(node)['display'] != "inline")  ){
            continue;
        }
        txt += node.getAttribute(DATACONTENT)
    }
    
    return txt
}


/**
 * checks if link contains hidden sponsored letters (revision August 2019). 
 * Facebook  adds in the "sponsored" tag hidden letters that have a "display" of none
 * and their values are stored as attribute values of the data-content attribute
 * so this is required to find sponsored tags
 * In this method we capture the parent of the sponsored tag
 *
 * @param  {object}  elem DOM element(subtitle tag) to be examined
 * @return {Boolean}      true if it contains the masked "Sponsored" tag, else false
 */
function isSpanSponsoredTagHiddenLettersAttributeValues(elem){

    var children = elem.childNodes;

    if ((children==null) || (children.length==0)) {
        return false;
    }

    var firstChild = children[0];

    var linkChild = firstChild.getElementsByTagName(LINK_TAG);

    if ((linkChild==null) || (linkChild.length!=1)) {
        //TODO:SEND MESSAGE IF LENGTH  IS NOT 1
        //
        return false;
    }

    linkChild = linkChild[0];

    linkChildChild = linkChild.childNodes;

    if ((linkChildChild==null) || (linkChildChild.length!=1)) {
        //TODO:SEND MESSAGE IF LENGTH  IS NOT 1
        //
        return false;
    }

    linkChildChild = linkChildChild[0];

    sponsoredChildren = linkChildChild.childNodes;

    if ((sponsoredChildren==null) || (sponsoredChildren.length==0)) {
        return false;
    }


    var tag = getNonHiddenTextInAttributeByChildren(sponsoredChildren);

    for (let i=0;i<SPONSORED.length;i++) {
        if (tag===SPONSORED[i]) {
            return true;
        }
    }
    
    return false



}



/**
 * check if sponsored link is hidden based on its computed style.
 * 
 * @param  {object}  el DOM object that corresponds to the sponsored link
 * @return {Boolean}    true if its computed style is None 
 * which means that it does not appear. 
 */
function isSponsoredLinkHidden(el) {
    var style = window.getComputedStyle(el);
    return (style.display === 'none')
}


/**
 * return Front ads that contain links with the masked "Sponsored" tag
 * 
 * @return {array} array of links that contain the sponsored tag
 */
function findFrontAdsWithHiddenLetters() {
    var elems = document.getElementsByTagName(LINK_TAG);
    var links = [];
    for (let i=0;i<elems.length;i++) {
        if ((isLinkSponsoredHiddenLetters(elems[i])) && (isScrolledIntoView(elems[i]))) {
            links.push(elems[i]);
        }
    }
    
    return links;
    
}

/**
 * add links that are marked with the class name of GRAB_ME (for test reasons)
 * 
 * @param  {array} links links that have the sponsored tag
 * @return {array}       links that have the sponsored tag + links that hae the class name GRAB_ME
 */
function getGrabbed(links){
    var elems=document.getElementsByClassName(GRAB_ME)
    for (let i=0;i<elems.length;i++) {
        links.push(elems[i])
        elems[i].classList.remove(GRAB_ME)
    }
    return links
}



/**
 * get all children of a DOM element (skip specific element)
 *
 * @param  {object} n      DOM element to be examined
 * @param  {object} skipMe DOM element to be excluded from the list
 * @return {array}         array of DOM elements that are children of n
 */
function getChildren(n, skipMe){
    var r = [];
    for ( ; n; n = n.nextSibling ) 
       if ( n.nodeType == 1 && n != skipMe)
          r.push( n );        
    return r;
};


/**
 * get siblings of DOM element n
 * 
 * @param  {object} n DOM element n
 * @return {array}    array containing all DOM siblings of n
 */
function getSiblings(n) {
    return getChildren(n.parentNode.firstChild, n);
}



/**
 * return siblings of element that have sponsored tag 
 * (different way of masking sponsored tag where the link 
 * is a sibling of the elements that contain the masked "Sponsored tag")
 * 
 * @param  {object} n DOM element n
 * @return {array}    array containing all DOM siblings of n
 */
function areSiblingsSponsored(elem){

    var siblings = getSiblings(elem);

    for (let i=0;i<siblings.length;i++) {
        if (isLinkSponsoredHiddenLetters(siblings[i])) {
            return true;
        }
    }

    return false;

}


/** 
 * find all links whose siblings contain the "Sponsored" tag
 *
 * @return {array} array containing all the sponsored links
 */
function findFrontAdsWithHiddenLettersSiblings(){
    var linksPrivacy = document.getElementsByClassName(UISTREAMPRIVACY)

    var links = [];

    for (let i=0;i<linksPrivacy.length;i++) {
        if (areSiblingsSponsored(linksPrivacy[i])) {
            links.push(linksPrivacy[i])        
        }
    }

    return links;

}



/** 
 * find all elements that contain the "Sponsored" tag when we have hidden letters 
 * and letters are stored as attribute values
 *
 * @return {array} array containing all the sponsored links
 */
function findFrontAdsWithHiddenLettersAttributeValues() {
    var linksSubtitles= $("["+DATATESTID+"="+SUBTITLE_TAG_DATATESTID+"]")

    var links = [];
    for (let i=0;i<linksSubtitles.length;i++) {
        // if ((isSpanSponsoredTagHiddenLettersAttributeValues(linksSubtitles[i])) && (!isSponsoredLinkHidden(linksSubtitles[i]))) {
        if ((isSpanSponsoredTagHiddenLettersAttributeValues(linksSubtitles[i])) && (isScrolledIntoView(linksSubtitles[i]))) {

            links.push(linksSubtitles[i]);
        }
    }
    
    return links;
}

/**
 * get all front ad DOM elements. Since several methods have been employed over the years,
 * and Facebook is known to return to old methods from time to time, we use all methods in conjuction
 * 
 * 
 * @return {array} array containing all front ads
 */
function getFrontAdFrames() {
    
    var links = document.getElementsByTagName(LINK_TAG);
    links = filterFrontAds(links);

    Array.prototype.push.apply(links,getFrontAdsByClass());
    links = links.unique();

    
    
    Array.prototype.push.apply(links,findFrontAdsWithHiddenLetters());

    Array.prototype.push.apply(links,findFrontAdsWithHiddenLettersSiblings());
    Array.prototype.push.apply(links,findFrontAdsWithHiddenLettersAttributeValues());




    
    links = getGrabbed(links);

    var already_in_list = new Set([]);
//    console.log(links)
    var frontAds = [];
    for (var i=0;i<links.length;i++) {
        var link = links[i];
        var frame = getParentAdDiv(link);
        if (already_in_list.has(frame.id)) {
            continue
        }

        frontAds.push(frame);  
        already_in_list.add(frame.id)  
    }
//    frontAds = frontAds.unique();
    return filterCollectedAds(frontAds);
    
    
}


/**
 * return landing pages and images from the front ads. 
 * Currently landing pages are not updated, so we collect only a subset.
 *
 * @param  {array} links    array of link DOM elements that are included in the front ad
 * @param  {object} frontAd DOM element of the front ad
 * @return {array}          array (essentially tuple) that contains the landing page urls and the image urls
 */
function getLandingPagesFrontAds(links,frontAd) {
    var landingPages = [];
    var images = []
    for (let i=0;i<links.length;i++) {
        let link = links[i];
        let onmouseover= link.getAttribute(ONMOUSEOVER);
        if (!onmouseover) {
            continue
        }
        
        let imgs = link.getElementsByTagName('img');
        if (imgs.length>0) {
            for (let j=0;j<imgs.length;j++) {
                if (imgs[j].src) {
                    images.push(imgs[j].src)   
                    continue
                }
                    console.log(imgs[j])
            }
        }
        if ( (onmouseover.indexOf(LINKSHIMASYNCLINK)===-1)) {
            continue
        }
        
        
        let urls = onmouseover.match(SWAPINGFUNCTION);
        if (!urls) {
            continue
        }
        
        
        landingPages.extend(urls);
        
    }
    
    
        var additionalImages = frontAd.getElementsByClassName('scaledImageFitWidth');
//    console.log(additionalImages)
    for (let i=0;i<additionalImages.length;i++) {
        images.push(additionalImages[i].src);

    }
    
        var additionalImages = frontAd.getElementsByClassName('scaledImageFitHeight');
//    console.log(additionalImages)
    for (let i=0;i<additionalImages.length;i++) {
        images.push(additionalImages[i].src);

    }
    
    
                var additionalImages = frontAd.getElementsByClassName('_kvn img');
//    console.log(additionalImages)
    for (let i=0;i<additionalImages.length;i++) {
        images.push(additionalImages[i].src);

    }
    

    return [landingPages.unique(),images.unique()];
}



/**
 * return landing pages and images from the side ads. 
 * Currently landing pages are not updated, so we collect only a subset.
 *
 * @param  {array} links    array of link DOM elements that are included in the front ad
 * @param  {object} sideAd DOM element of the front ad
 * @return {array}          array (essentially tuple) that contains the landing page urls and the image urls
 */   
function getLandingPagesSideAds(links,sideAd) {
    var landingPages = [];
    var images = []
    for (let i=0;i<links.length;i++) {
        let link = links[i];
        let onmousedown= link.getAttribute(ONMOUSEDOWN);
        if (!onmousedown) {
            continue
        }
        
        let imgs = link.getElementsByTagName('img');
        if (imgs.length>0) {
            for (let j=0;j<imgs.length;j++) {
                if (imgs[j].src) {
                    images.push(imgs[j].src)   
                    continue
                }
                    console.log(imgs[j])
            }
        }
    
        
        
        let urls = [link.href]
        if (!urls) {
            continue
        }
        
        
        landingPages.extend(urls);
        
    }
    
    var additionalImages = sideAd.getElementsByClassName('scaledImageFitWidth');
//    console.log(additionalImages)
    for (let i=0;i<additionalImages.length;i++) {
        images.push(additionalImages[i].src);

    }
    
        var additionalImages = sideAd.getElementsByClassName('scaledImageFitHeight');
//    console.log(additionalImages)
    for (let i=0;i<additionalImages.length;i++) {
        images.push(additionalImages[i].src);

    }
    

                var additionalImages = sideAd.getElementsByClassName('_kvn img');
//    console.log(additionalImages)
    for (let i=0;i<additionalImages.length;i++) {
        images.push(additionalImages[i].src);

    }
    
    
    return [landingPages.unique(),images.unique()];

}
var ADSA;

/**
 * @deprecated  returns image urls from the image array
 * 
 * @param  {array} images  array of image DOM elements
 * @return {array}         array of the urls of the images
 */
function getImageUrls(images) {
    var urls = []
    for (let i=0;i<images.length;i++) {
        let src = images[i].src
        if ((src) && (src.length>0)) {
            urls.push(src)
        }
    }
    return urls
}


/**
 * return advertiser id from the front ad
 *
 * 
 * @param  {object} frontAd DOM element of the front ad
 * @return {string}         advertiser id
 */
function getAdvertiserId(frontAd) {
    let links = frontAd.getElementsByTagName(LINK_TAG);
    let link = null
    for  (let i=0;i<links.length;i++) {
        if (links[i].hasAttribute(DATA_HOVERCARD) && (links[i].getElementsByTagName('img').length>0)) {
            link = links[i];
            break
        }
    }
    
    if (!link) {
        return 
    }
    
//    let advertiserId = link.getAttribute(DATA_HOVERCARD).replace(ADVERTISER_FB_ID_PATTERN,"")
    var advertiserId = '-1';
    try {
         let hovercard = link.getAttribute(DATA_HOVERCARD)
//    var urlad = new URL(hovercard);
         advertiserId = hovercard.match(ADVERTISER_ID_PATTERN_IDENTIFIER)[0].match(NUMBER_TAG)[0]
//     advertiserId= urlad.searchParams.get("id");
    if (!isNumeric(advertiserId)) {
        advertiserId ='-1';
    }
        
    } catch (e) {
        console.log(e)
    }
   
    let facebookPage = link.href.substring(0, link.href.indexOf('?'));
    let advertiserImage = link.getElementsByTagName('img')[0].src
    return [advertiserId,facebookPage,advertiserImage]
    
}


/**
 * check if front ad contains a video
 * 
 * @param  {object}  frontAd DOM element of front ad
 * @return {Boolean}         true if front ad has a video, else false
 */
function isVideo(frontAd) {
    return frontAd.getElementsByTagName('video').length>0
}


/**
 * get video id of front ad video
 * 
 * @param  {object} frontAd DOM element of front ad
 * @return {string(TODO: check if number)}         video id of front ad
 */
function getVideoId(frontAd) {
    let videoId=null;
    inputs = frontAd.getElementsByTagName(INPUT);
    for (let i=0;i<inputs.length;i++) {
        if (inputs[i].getAttribute(NAME) === FT_ENT_IDENTIFIER) {
            videoId = inputs[i].getAttribute(VALUE)
        }
    }
    return videoId
}

/**
 * return the image urls of background elements. Essentially grabs the preview snapshot of a video.
 * @param  {object} frontAd DOM element of front ad
 * @return {[array]}        array of background image urls
 */
function getBackgroundUrlImages(frontAd) {
    let images = [];
    

    var additionalImages = frontAd.getElementsByTagName('img');
    for (let i=0;i<additionalImages.length;i++) {
        if (additionalImages[i].outerHTML.indexOf(BACKGROUNDIMAGE)>-1) {
            let backgroundImage = additionalImages[i].style.backgroundImage.replace('url("','')
            backgroundImage = backgroundImage.slice(0,backgroundImage.length-2)
            images.push(backgroundImage);
        }
    }
        
    
//    for (let i=0;i<imgs.length;i++) {
//        let img = imgs[i]
//        if (img.getAttribute(STYLE)) {
//            console.log(img)
//            var url = img.getAttribute(STYLE).match(URL_REGEXP);
//            console.log(url)
//            if ((url) && (url.length>0)) {
//                images.push(url[0].substring(0,url[0].length-2));
//            }
//        }
//    }
    return images
    
}




/**
 * processes front ad object adding in the object 
 * all the data/meta data that we save in the server (except of explanation of the ad)
 * 
 * @param  {object} frontAd DOM element of the front ad
 * @return {object}         object to be send to the server
 */
function processFrontAd(frontAd) {

    //frontAd.className += " " + COLLECTED;
    var html_ad_id = frontAd.id;
    console.log('frontAd id: ' + frontAd.id)
    ADSA = frontAd
    let info = getAdvertiserId(frontAd);

    var advertiser_facebook_id = info ? info[0] : "";
    var advertiser_facebook_page = info ? info[1] : "";
    var advertiser_facebook_profile_pic = info ? info[2] : "";

    var raw_ad = frontAd.innerHTML;
    //var raw_ad = frontAd.outerHTML;
    var timestamp = (new Date).getTime();
    var pos = getPos(frontAd);
    var offsetX = pos.x;
    var offsetY = pos.y;
    var type = TYPES.frontAd;
    var [landing_pages, images] = getLandingPagesFrontAds(frontAd.getElementsByTagName(LINK_TAG), frontAd);
    var video = isVideo(frontAd)
    var video_id = ''
    if (video) {
        video_id = getVideoId(frontAd);
        images = getBackgroundUrlImages(frontAd);

    }

    var user_id = getUserId();

    //check position ad visible state of ad at time when ad collected
    try{
    var ad_elem = document.getElementById(html_ad_id);
    var domPos = getElementCoordinate(ad_elem)
    var relPos = toRelativeCoordinate(domPos)
    var isInView = (relPos == undefined) ? false : true;
    var visible_fraction = []
    if (relPos != undefined) {
        var visible_state = getVisibleHeight(ad_elem);
        visible_fraction = (visible_state[2] >= 0) ? (visible_state[0] / visible_state[1]) :
            (-visible_state[0] / visible_state[1]);
    }
    }catch(e){
        console.log('Error while compute ad position');
        console.log(e);
    }

    // console.log('+++++++++++++')
    // console.log(getDomPosition(ad_elem))
    // console.log(getUserView())
    // console.log(isInView)
    //TODO:GET IMAGE URL
    //    var image_urls = getImageUrls(frontAd.getElementsByTagName('img'));

    //       fb_id = 
    //    fb_advertiser_id = 
    
    return { 'raw_ad': raw_ad, 'html_ad_id': html_ad_id, 'visible': isInView, 'visible_fraction': visible_fraction, 'visibleDuration': [], 'timestamp': timestamp, 'offsetX': offsetX, 'offsetY': offsetY, 'type': type, 'landing_pages': landing_pages, 'images': images, 'user_id': user_id, advertiser_facebook_id: advertiser_facebook_id, advertiser_facebook_page: advertiser_facebook_page, advertiser_facebook_profile_pic: advertiser_facebook_profile_pic, video: video, video_id: video_id }


}


/**
 * processes side ad object adding in the object 
 * all the data/meta data that we save in the server (except of explanation of the ad)
 * 
 * @param  {object} frontAd DOM element of the side ad
 * @return {object}         object to be send to the server
 */
function processSideAd(sideAdObj,adId) {
     
//    frontAd.className += " " + COLLECTED;
//    console.log(frontAd)
//    ADSA = frontAd

    var sideAd = sideAdObj[DOM_AD];
    sideAd.className += " " + COLLECTED;

    var raw_ad = sideAd.innerHTML;
    var timestamp = (new Date()).getTime();
    var pos = getPos(sideAd);
    var offsetX = pos.x;
    var offsetY = pos.y;
    var type = TYPES.sideAd;
    var [landing_pages,images] = getLandingPagesSideAds(sideAd.getElementsByTagName(LINK_TAG),sideAd);
    
    //TODO:GET IMAGE URL
//    var image_url = 
    var fb_id = adId;
    var fb_advertiser_id = sideAdObj[AD_ACCOUNT_ID];
//    console.log(fb_advertiser_id);
    var user_id = getUserId();
    return {'raw_ad':raw_ad,'timestamp':timestamp,'offsetX':offsetX,'offsetY':offsetY,'type':type,'user_id':user_id,'fb_id':fb_id,'fb_advertiser_id':fb_advertiser_id,landing_pages:landing_pages,images:images}
    
    
}

/**
 * get the DOM element that cprresponds to the more button of the (TODO: make sure it is only front) ad
 *
 * 
 * @param  {object} adFrame DOM element of the ad
 * @return {object}         more button DOM element
 */
function getMoreButtonFrontAd(adFrame) {
    var links = adFrame.getElementsByTagName(LINK_TAG);
    for (var i=0;i<links.length;i++) {
        if (MORE_LINK_FRONT_LABEL.indexOf(links[i].getAttribute(ARIA_LABEL))>=0) {
            return links[i]
        }
    }
    
    
    
}


/**
 * @deprecated get explanation button of front ad
 * @param  {object} adFrame DOM element of front ad
 * @return {array}          tuple containing the ad id an the link for the explanation
 */
function getExplanationButtonFrontAd(adFrame) {
    var mainWindow = document

    var links = mainWindow.getElementsByTagName('a')
    for (let i=0;i<links.length;i++) {
        let link = links[i];
        let ajaxify = link.getAttribute(AJAXIFY);
        if ((ajaxify) && (ajaxify.indexOf(AD_LINK) != -1) && (link.text) && (EXPLANATION_TEXT.indexOf(link.text)>=0)) {
            var ad_id = extract_ad_id(ajaxify)
            var postPattern = ajaxify.match(FRONTADPOSTPATTERN);
            if ((postPattern )&& (postPattern.length>0)) {
                 var postId = postPattern[0].replace(FRONTADPOSTPATTERNSTRING,'')
                if (adFrame.innerHTML.indexOf('value="'+postId)!=-1) {
                return [ad_id,link]
            }
                
            }
            postPattern = ajaxify.match(FRONTADPOSTPATTERN2);

//        
//            if ((!postPattern) || (postPattern.length==0)) {
////                console.log(ajaxify)
//                continue;
//            }
              if ((postPattern )&& (postPattern.length>0)) {
             var postId2 = postPattern[0].replace(FRONTADPOSTPATTERNSTRING2a,'').replace(FRONTADPOSTPATTERNSTRING2b,'')
                if (adFrame.innerHTML.indexOf(postId2)!=-1) {
                return [ad_id,link]
                }
                  }
            
            
                        postPattern = ajaxify.match(FRONTADPOSTPATTERN3);

//        
//            if ((!postPattern) || (postPattern.length==0)) {
////                console.log(ajaxify)
//                continue;
//            }
              if ((postPattern )&& (postPattern.length>0)) {
             var postId2 = postPattern[0].replace(FRONTADPOSTPATTERNSTRING3a,'').replace(FRONTADPOSTPATTERNSTRING3b,'')
                if (adFrame.innerHTML.indexOf(postId2)!=-1) {
                return [ad_id,link]
                }
                  }
            
        }   
        
    }
    return [false,false];
} 

//function getFrontAdExplanationLink(adFrame) {
//    
//    var moreButton =  getMoreButtonFrontAd(adFrame);
//    var buttonId = moreButton.parentElement.id;
//    moreButton.click();
//    moreButton.click();
////    var adLinks = get_ads(adFrame);
//    var count = 10;
////    var overlay = document.getElementsByClassName(FRONTAD_OVERLAY);
//    while (count>0) {
//        var [adId,adLink]  = getExplanationButtonFrontAd(adFrame);
//        if (adId!=false) {
//            return [adId,adLink,buttonId]
//        }
//        count--;
//    }
//    
//    return [false,false,buttonId];
//    
//    
//
//    
//}


//
//function getFrontAdExplanationLink(adFrame) {
//    
//    var moreButton =  getMoreButtonFrontAd(adFrame);
//    
//    var buttonId = moreButton.parentElement.id;
//    
//    
////    var adLinks = get_ads(adFrame);
//    var count = 10;
////    var overlay = document.getElementsByClassName(FRONTAD_OVERLAY);
//    while (count>0) {
//        var [adId,adLink]  = getExplanationButtonFrontAd(adFrame);
//        if (adId!=false) {
//            return [button]
//        }
//        count--;
//    }
//    
//    return [false,false];
//    
//    
//
//    
//}



/**
 * return the id of the "More" button to be used to match it with the more button in the overloaded script
 * @param  {object} adFrame DOM element of the front ad
 * @return {string}         id of the "More" button
 */
function getButtonId(adFrame) {
    var moreButton = getMoreButtonFrontAd(adFrame);
    return moreButton.parentElement.id;
}

/**
 * hover over the front ad's "More" button. This triggers the an ajax request to Facebook
 * which retrieves the more button contents, including the parameters 
 * embeded in the "Why Am I Seiing This?" button.
 * 
 * @param  {object} adFrame DOM element of the front ad
 * @return 
 */
function hoverOverButton(adFrame) {
    
    var moreButton = getMoreButtonFrontAd(adFrame);
    moreButton.dispatchEvent(new MouseEvent('mouseover'));
}



//function strip(html)
//{
//   var tmp = document.createElement("DIV");
//    
//   tmp.innerHTML = html.replace(/\\u003c/gi,"<").replaceAll('\\','');
//    
//    var txt = '';
//    
//    for (var i =0;i<tmp.childNodes.length;i++) {
//        txt +='. ' + tmp.childNodes[i].textContent || tmp.childNodes[i].innerText || ""
//    }
//    
//   return txt ;
//}



/**
 * @deprecated  retrieve side ads. (was used when clicking on the more button)
 * @param  {object} doc DOM element to be investigated
 * @return {TODO: check what is being returned}     [description]
 */
function getAds(doc) {
    
    var links = doc.getElementsByTagName(LINK_TAG);
//    MAYBE SAME AD APPEARS MORE THAN ONCE?
    var ad_links = {};
    for (var i=0;i<links.length;i++){
        var link = links[i];
        var ajaxify = link.getAttribute(AJAXIFY);
        if ((ajaxify) && (ajaxify.indexOf(AD_LINK) != -1) && (link.text) && (EXPLANATION_TEXT.indexOf(link.text)>=0)) {
            var ad_id = extract_ad_id(ajaxify)
            ad_links[ad_id] = link
        }   
    }
    return ad_links;  
    
}


/**
 * create a json object that is derived from URL Get parameters and their values
 * @param  {string} params URL get parameters
 * @return {object}        desired object
 */
var createObjFromURI = function(params) {
    var uri = decodeURI(params);
    var chunks = uri.split('&');
    var params = Object();

    for (var i=0; i < chunks.length ; i++) {
        var chunk = chunks[i].split('=');
        if(chunk[0].search("\\[\\]") !== -1) {
            if( typeof params[chunk[0]] === 'undefined' ) {
                params[chunk[0]] = decodeURIComponent([chunk[1]]);

            } else {
                params[chunk[0]].push(decodeURIComponent(chunk[1]));
            }


        } else {
            params[chunk[0]] = decodeURIComponent(chunk[1]);
        }
    }

    return params;
}



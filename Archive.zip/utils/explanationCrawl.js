//The MIT License
//
//Copyright (c) 2018 Athanasios Andreou, <andreou@eurecom.fr>
//
//Permission is hereby granted, free of charge, 
//to any person obtaining a copy of this software and 
//associated documentation files (the "Software"), to 
//deal in the Software without restriction, including 
//without limitation the rights to use, copy, modify, 
//merge, publish, distribute, sublicense, and/or sell 
//copies of the Software, and to permit persons to whom 
//the Software is furnished to do so, 
//subject to the following conditions:
//
//The above copyright notice and this permission notice 
//shall be included in all copies or substantial portions of the Software.
//
//THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
//EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES 
//OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. 
//IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR 
//ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, 
//TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
//SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

//*********************GLOBAL VARIABLES*********************************************
//
//** Capture explanation popup based on properties of JSON response object**********
var CAPTCHA_EXPLANATION_MSG = ['captcha_dialog'];
var ERROR_EXPLANATION_MSG = ['errorDescription']
var CAPTCHA_DETECTED = -1;
var TIMESTAMP_SHOWN_POPUP = -1;
var ONE_WEEK_EPOCH = 604800000;
var NOT_SHOW_POPUP_AGAIN = -1;


var ABOUT_THIS_FACEBOOK_AD =['About This Facebook Ad','About this Facebook ad','propos de cette pub Facebook'];
var MANAGE_YOUR_AD_PREFERENCES =['Manage Your Ad Preferences','Manage Your ad preferences','G\u00e9rer vos pr\u00e9f\u00e9rences'];

var DOCID = '2602243929890886';

var GRAPHQLURL ='https://www.facebook.com/api/graphql/'
/************+**********FUNCTIONS THAT HANDLE THE EXPLANATION THE SCHEDULING OF THE EXPLANATIONS******************
/**
 * Get the timestamps of when explanations requests took place that are scheduled and stored at local storage
 * @return {object} explanation requests that took place and stored at local storage
 */
function getExplanationRequests() {
if (!localStorage.explanationRequests) {
        localStorage.explanationRequests = JSON.stringify({})
    }
    
    return JSON.parse(localStorage.explanationRequests);
}


/**
 * Get the timestamps of when explanation for each ad was received from the local storage
 * @return {object} crawled explanations
 */
function getCrawledExplanations() {
    if (!localStorage.crawledExplanations) {
        localStorage.crawledExplanations = JSON.stringify({})
    }
    
    return JSON.parse(localStorage.crawledExplanations);
    
}

/**
 * Get the queue for the explanation requests that are scheduled to take place from the local storage
 * @return {object} explanations queu
 */
function getExplanationsQueue() {
    if (!localStorage.explanationsQueue) {
        localStorage.explanationsQueue = JSON.stringify({})
    }
    
    return JSON.parse(localStorage.explanationsQueue);
    
}

/**
 * Returns true if an explanation is already in the queue or has been crawled. Also if user does not exist in the global parameters, it initiates it.
 *  (requires the GLOBAL objects of CRAWLED_EXPLANATIONS and EXPLANATIONS_QUEUE)
 * @param  {String}  adId   Facebook ad id
 * @param  {String}  userId User id
 * @return {Boolean}        true if explanation for ad with ad id already in the queue or has been crawled
 */
function isCrawledOrQueue(adId,userId) {
     if (!CRAWLED_EXPLANATIONS[userId]) {
        CRAWLED_EXPLANATIONS[userId]={};
    }
    
    if (!EXPLANATIONS_QUEUE[userId]) {
        EXPLANATIONS_QUEUE[userId] = {}
    }
    return ((adId in CRAWLED_EXPLANATIONS[userId]) || (adId in EXPLANATIONS_QUEUE[userId]))
}



function getNextExplanation(fbId) {
    let queuedIds = Object.keys(EXPLANATIONS_QUEUE[fbId]);
    let ts = (new Date()).getTime();
    let oldestId = {adId:-1,'timestamp':0};
    
    for (let i =0;i<queuedIds.length;i++) {
        console.log(queuedIds[i]);
        console.log(EXPLANATIONS_QUEUE[fbId][queuedIds[i]])
        if (ts - EXPLANATIONS_QUEUE[fbId][queuedIds[i]]['timestamp'] > DAY_MILISECONDS) {
            try {
                console.log('DELETING explanation',ts,EXPLANATIONS_QUEUE[fbId][queuedIds[i]]['timestamp'],DAY_MILISECONDS)
                delete EXPLANATIONS_QUEUE[fbId][queuedIds[i]];
                continue;
            } catch (e) {
                console.log("EXCEPTION IN getExplanation");
                console.log(e)
            }
        }
        console.log(queuedIds[i]);
        console.log(EXPLANATIONS_QUEUE[fbId][queuedIds[i]])
        
        if ((ts - EXPLANATIONS_QUEUE[fbId][queuedIds[i]]['timestamp'] <= DAY_MILISECONDS) && (EXPLANATIONS_QUEUE[fbId][queuedIds[i]]['timestamp'] >= oldestId['timestamp'])){
            oldestId.adId = queuedIds[i];
            oldestId.timestamp = EXPLANATIONS_QUEUE[fbId][queuedIds[i]]['timestamp'];
            
            
            
        }
    }
    
    try {
        let obj = EXPLANATIONS_QUEUE[fbId][oldestId.adId];
        if (oldestId.adId==-1) {
            return -1
        }
        console.log('Oldest obj is '+oldestId.adId)
        delete EXPLANATIONS_QUEUE[fbId][oldestId.adId];
        return [oldestId.adId,obj.explanationUrl,obj.dbRecordId,obj.timestamp,obj.graphQLAsyncParams,obj.clientToken];
    } catch(e) {
            console.log("EXCEPTION IN getNextExplanation returning");
                console.log(e)
                return -1;
            }

}


function addToQueueExplanations(fbId,adId,explanationUrl,dbRecordId,graphQLAsyncParams,clientToken) {
    console.log('ADDING to queue')
    
   if (!CRAWLED_EXPLANATIONS[fbId]) {
        CRAWLED_EXPLANATIONS[fbId]={};
    }
    
    if (!EXPLANATIONS_QUEUE[fbId]) {
        EXPLANATIONS_QUEUE[fbId] = {}
    }
    
    let queuedIds = Object.keys(EXPLANATIONS_QUEUE[fbId]);
    let ts = (new Date()).getTime();
    
    for (let i =0;i<queuedIds.length;i++) {
        if (ts - EXPLANATIONS_QUEUE[fbId][queuedIds[i]]['timestamp'] > DAY_MILISECONDS) {
            try {
             delete EXPLANATIONS_QUEUE[fbId][queuedIds[i]];
            } catch (e) {
                console.log("EXCEPTION IN addToQueueExplanations");
                console.log(e)
            }
        }
    }
    
    queuedIds = Object.keys(EXPLANATIONS_QUEUE[fbId]);
    let crawledIds = Object.keys(CRAWLED_EXPLANATIONS[fbId]);
    
    
    if ((adId in queuedIds) || (adId in crawledIds)) {
        console.log('In here');
        return false
    } 
    
    console.log('Time here is ',ts);
    
    EXPLANATIONS_QUEUE[fbId][adId] = {timestamp:ts,explanationUrl:explanationUrl,dbRecordId:dbRecordId,graphQLAsyncParams:graphQLAsyncParams,clientToken:clientToken}
    return true
    
}






//************+**********FUNCTIONS RELATED TO THE RETRIEVING OF THE EXPLANATIONS******************

/**
 * Trigger popup to the Facebook page of user in order to ask them to solve a captcha for the explanations.
 * This should be triggered only once to a user
 * @return {} 
 */
function triggerCaptchaPopup(){
    CAPTCHA_DETECTED = 1;
    localStorage.captchaDetected = CAPTCHA_DETECTED;
    if (NOT_SHOW_POPUP_AGAIN == 1) 
    {
    	return;
    }
                    
    //Send msg to content script -> Show the message to user
    var tsNow = (new Date()).getTime()
    if (TIMESTAMP_SHOWN_POPUP == -1 || TIMESTAMP_SHOWN_POPUP <= (tsNow - ONE_WEEK_EPOCH)) {
        chrome.tabs.query({}, function (tabs) {
            for (let i = 0; i < tabs.length; i++) {
            	try {
                    chrome.tabs.sendMessage(tabs[i].id, {
                    type: "showInfoPopup"
                    }, function (response) {});
                } catch (err) {
                    console.log(err)
                }
            }	
        });
    }
}

/**
 * send error message in the server with the specification that there is a captcha message
 * @param  {[type]} adId           [description]
 * @param  {[type]} explanationUrl [description]
 * @param  {[type]} dbRecordId     [description]
 * @param  {[type]} timestamp      [description]
 * @param  {[type]} response       [description]
 * @return {[type]}                [description]
 */
function sendCaptchaMessage(adId,explanationUrl,dbRecordId,timestamp,response,graphQLAsyncParams,clientToken) {
	//FLAG TO NOT COLLECT EXPLANATIONS FOR TWO HOURS IF CAPTCHA MESSAGE APPEARS
    WAIT_FOR_TWO_HOURS=true;
	var errorInfo = {};
    errorInfo[MSG_TYPE] = ERROR_TYPES.BACKGROUND_PROBLEM;
    errorInfo[ERROR_MESSAGE] = "Captcha issue: {adId : " + adId + ", response : " + response + ", dbId: " + dbRecordId + "} - "+ getExtensionVersion();
    sendErrorMessage(errorInfo, URLS_SERVER.registerError);

    // RESCHEDULE THE EXPLANATION
    EXPLANATIONS_QUEUE[CURRENT_USER_ID][adId] =	{adId:adId,explanationUrl:explanationUrl,dbRecordId:dbRecordId,timestamp:timestamp,graphQLAsyncParams:graphQLAsyncParams,clientToken:clientToken};

	triggerCaptchaPopup();
}

/**
 * send generic error in the server
 * @param  {[type]} adId           [description]
 * @param  {[type]} explanationUrl [description]
 * @param  {[type]} dbRecordId     [description]
 * @param  {[type]} timestamp      [description]
 * @param  {[type]} response       [description]
 * @return {[type]}                [description]
 */
function sendGenericErrorMessage(adId,explanationUrl,dbRecordId,timestamp,response,graphQLAsyncParams,clientToken) {
    WAIT_FOR_TWO_HOURS=true;
    // console.log(response);
    EXPLANATIONS_QUEUE[CURRENT_USER_ID][adId] =
        {adId:adId,explanationUrl:explanationUrl,dbRecordId:dbRecordId,timestamp:timestamp,graphQLAsyncParams:graphQLAsyncParams,clientToken:clientToken}

    var errorInfo = {};
    errorInfo[MSG_TYPE] = ERROR_TYPES.BACKGROUND_PROBLEM;
    errorInfo[ERROR_MESSAGE] = "Explanation error: {adId : " + adId + ", response : " + response + ", dbId: " + dbRecordId + "} - "+ getExtensionVersion();
    sendErrorMessage(errorInfo, URLS_SERVER.registerError);
}

/**
 * send error message to the server when explanation request fails
 * @return {} 
 */
function sendRequestErrorMessage(adId,dbRecordId,xmlhttp,isGraphQl=false) {
    var errorInfo = {};
    errorInfo[MSG_TYPE] = ERROR_TYPES.BACKGROUND_PROBLEM;
    errorInfo[ERROR_MESSAGE] = "Explanation response error "+ (isGraphQl?"graphql":"") +": {adId: " +adId+ + ", dbId: " + dbRecordId + ", readyState:" + xmlhttp.readyState + ", status:" + xmlhttp.status + ", response: " + xmlhttp.responseText + "} - " + getExtensionVersion();
    sendErrorMessage(errorInfo, URLS_SERVER.registerError);
}

/**
 * checks if explanation is of the old type (plain text explanation) and it was received normally. (This works only for specific languages)
 * @param  {string}  response the response text from the explanation request
 * @return {Boolean}          true if it is old type of explanation
 */
function isOldExplanation(response) {
    var expStart = getIndexFromList(response,ABOUT_THIS_FACEBOOK_AD);
    var expEnd = getIndexFromList(response,MANAGE_YOUR_AD_PREFERENCES);
    return ((expStart!==-1) && (expEnd!==-1));
}



/**
 * send error message to the server when explanation request (graphql) contains an empty targeting data field
 * @return {} 
 */
function sendNoTargetingDataErrorMessage(adId,dbRecordId,response) {
    var errorInfo = {};
    errorInfo[MSG_TYPE] = ERROR_TYPES.BACKGROUND_PROBLEM;
    errorInfo[ERROR_MESSAGE] = "Explanation error graphql waist_targeting_data exists but is empty: {adId : " + adId + ", response : " + response + ", dbId: " + dbRecordId + "} - "+ getExtensionVersion();
    sendErrorMessage(errorInfo, URLS_SERVER.registerError);
}



/**
 * send error message to the server when explanation request (graphql) contains an empty targeting data field
 * @return {} 
 */
function sendDifferentTargetingDataErrorMessage(adId,dbRecordId,response) {
    var errorInfo = {};
    errorInfo[MSG_TYPE] = ERROR_TYPES.BACKGROUND_PROBLEM;
    errorInfo[ERROR_MESSAGE] = "Explanation error graphql waist_targeting_data response does not have the required format: {adId : " + adId + ", response : " + response + ", dbId: " + dbRecordId + "} - "+ getExtensionVersion();
    sendErrorMessage(errorInfo, URLS_SERVER.registerError);
}


/**
 * checks if explanation response (using the GRAPHQL) cotnains targeting data
 * @param  {string}  response the responsne text from the graphql explaantion request
 * @return {boolean}          true if explanation response contains targeting data
 */
function containsTargetingDataGraphQL(response) {
	var responseObject = JSON.parse(response);
	return responseObject['data']['waist_targeting_data'].length >0;
}



/**
 *  
 * @param  {[type]} adId           [description]
 * @param  {[type]} explanationUrl [description]
 * @param  {[type]} dbRecordId     [description]
 * @param  {[type]} timestamp      [description]
 * @return {[type]}                [description]
 */
function getExplanationsManually(adId,explanationUrl,dbRecordId,timestamp,graphQLAsyncParams,clientToken) {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET",explanationUrl, true);
     xmlhttp.onload = function (e) {
        EXPLANATION_REQUESTS[CURRENT_USER_ID].push((new Date()).getTime())

        if (xmlhttp.readyState === 4 && xmlhttp.status === 200){

            var response = xmlhttp.responseText;

            //if explanation is of the old type send error
            if (isOldExplanation(response)) {
	            sendExplanationDB(adId,dbRecordId,response);
	            CAPTCHA_DETECTED = 0;
	            localStorage.captchaDetected = CAPTCHA_DETECTED;
            }

            // TODO: NOT SURE IF IT IS IMPORTANT TO SEND THE MESSAGES ANY MORE
            // TRY IF WE CAN GET EXPLANATIONS WITHOUT RATE LIMIT NOW
            //Keep loging if something weird happened
            if (getIndexFromList(response,CAPTCHA_EXPLANATION_MSG)!=-1) {
            	sendCaptchaMessage(adId,explanationUrl,dbRecordId,timestamp,response,graphQLAsyncParams,clientToken);	
            	return;
            }

            if (getIndexFromList(response,ERROR_EXPLANATION_MSG)!=-1) {
                
                sendGenericErrorMessage(adId,explanationUrl,dbRecordId,timestamp,response,graphQLAsyncParams,clientToken);
                return;
            }            


            //GET THE NEW TYPE OF EXPLANATIONS WITH GRAPHQURL

            CAPTCHA_DETECTED = 0;
        	localStorage.captchaDetected = CAPTCHA_DETECTED;
        	console.log('GraphQL EXPLANATION');
        	captureErrorBackground(getGraphQLExplanations,[adId,explanationUrl,dbRecordId,timestamp,graphQLAsyncParams,clientToken],URLS_SERVER.registerError,undefined);
        	return;

            
        }

        else {
			sendRequestErrorMessage(adId,dbRecordId,xmlhttp);
        }

    }
     
    xmlhttp.send(null);
            
    
}

/**
 * get the parameters required for a graphql ad request
 * @param  {[type]} adId        [description]
 * @param  {[type]} clientToken [description]
 * @param  {[type]} asyncParams [description]
 * @return {[type]}             [description]
 */
function getGraphQLPostParameters(adId,clientToken,asyncParams) {
	var params_extra = {'av':asyncParams.__user,'fb_api_caller_class':'RelayModern','fb_api_req_friendly_name':'AdsPrefWAISTDialogQuery',
					'variables':JSON.stringify({'adId':adId,'clientToken':clientToken}),'doc_id':DOCID};

	return {...params_extra,...asyncParams};

}



/**
 * get explanations from GraphQL
 * @param  {[type]} adId               [description]
 * @param  {[type]} explanationUrl     [description]
 * @param  {[type]} dbRecordId         [description]
 * @param  {[type]} timestamp          [description]
 * @param  {[type]} graphQLAsyncParams [description]
 * @param  {[type]} clientToken        [description]
 * @return {[type]}                    [description]
 */
function getGraphQLExplanations(adId,explanationUrl,dbRecordId,timestamp,graphQLAsyncParams,clientToken) {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.open("POST",GRAPHQLURL, true);
    xmlhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
  	xmlhttp.onload = function(e) {
            // Do whatever with response
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200){
            var containsTargetingData = captureErrorBackground(containsTargetingDataGraphQL,[xmlhttp.response],URLS_SERVER.registerError,undefined);
            console.log("Object contains targeting data:");
            console.log(containsTargetingData);
            if (containsTargetingData===undefined) {
            	sendDifferentTargetingDataErrorMessage(adId,dbRecordId,xmlhttp.response);
            	return;
            }

            if (containsTargetingData===true) {
	            sendExplanationDB(adId,dbRecordId,xmlhttp.response);

            	return;
            }

        	sendNoTargetingDataErrorMessage(adId,dbRecordId,xmlhttp.response);

        	//SENDING RESPONSE TO EXAMINE
            sendExplanationDB(adId,dbRecordId,xmlhttp.response);

        	return;

         }

		sendRequestErrorMessage(adId,dbRecordId,xmlhttp);

        }

    var allParams = getGraphQLPostParameters(adId,clientToken,graphQLAsyncParams);

    // TODO: PUT THE PARAMETERS IN SPECIFIC ORDER
    xmlhttp.send($.param(allParams));

}



